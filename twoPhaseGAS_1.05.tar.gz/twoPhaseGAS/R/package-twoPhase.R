
#' twoPhase genetic study design
#'
#' Documentation and examples can be found at the package directory folder inst / doc
#' or at our github url:
#' ...
#' https://github.com/adimitromanolakis/NOTYETAVAILABLE
#'
#'
"_PACKAGE"



#' @import MASS
#' @import stats
#' @import data.table
#' @import enrichwith
#' @import nloptr
#' @import dfoptim
#' @import Matrix

NULL
