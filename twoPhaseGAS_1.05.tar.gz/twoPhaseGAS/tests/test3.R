

# this example returned -5e+17
# need to fix
## Fixed now I think, the function was not taking the parameters needed. - July 5, 2019

sprintf("%f",-5.857006e+17 )

runExample2(Beta0 = 5000, Beta1 = 20, nrep=500)
