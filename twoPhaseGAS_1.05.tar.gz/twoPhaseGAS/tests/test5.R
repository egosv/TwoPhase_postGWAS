


N = 5000

data1 = runExample1(
  N = N, Beta0 = 10, Beta1 = 1
)

dat = data1$dat
opt.prop = data1$opt.prop
strataformula = data1$strataformula
beta0  = data1$beta0
p_gz0 = data1$p_gz0

# Perform basic stratified sampling on the optimal sampling probabilitites
R.optLM <- BSS.opt(samp.fracs=opt.prop$prR_cond_optim,dat,strata=strataformula) ## indicators for LM design


### Test the functions implementing the SPML model fitting
dat1 <- data1$dat_comp[R.optLM==1,c("Y","G1","G0","Z","S")] # phase 2 data
dat0 <-  data1$dat_comp[R.optLM==0,c("Y","Z","S")] # phase 2 data complement

## SNP under the null
resHo_0 <- twoPhaseSPML(formula=Y~1,miscov=~G0,auxvar=~Z,family=gaussian,dat0,dat1)
resHa_0 <- twoPhaseSPML(formula=Y~G0,miscov=~G0,auxvar=~Z,family=gaussian,dat0,dat1)

## SNP under the alternative
resHo_1 <- twoPhaseSPML(formula=Y~1,miscov=~G1,auxvar=~Z,family=gaussian,dat0,dat1)
resHa_1 <- twoPhaseSPML(formula=Y~G1,miscov=~G1,auxvar=~Z,family=gaussian,dat0,dat1)


### TODO code print method