

library(twoPhaseGAS)
getwd()

library(MASS)
library(Matrix)
library(data.table)
library(dfoptim)
library(enrichwith)
library(nloptr)

source("../R/twoPhase.R")

source("../R/optimJTC_v2.R")
source("../R/kofnGA_mc.R")
source("../R/DataGeneration.R")
source("../R/SPML_glm_multipleG.R")



nsample = 500


maf_G = 0.1
LD = 0.3

data = data.frame(  Y = rnorm(nsample),  Z = rbinom(nsample, 2, 0.2) ) 
beta = c( 1,1,1 )

n2 = 200
family = gaussian
design_formula =  Y ~  G  +  Z


#  result = twoPhase(beta = beta, maf_G = 0.1, LD = 0.3 , design_formula = Y ~  G  +  Z , data = data , n2 = 200 )


beta = list( c(1,1,1), c(1,2,1), c(1,3,1) )

result = twoPhaseOptimize(beta = beta, maf_G = c(0.1,0.2), LD = c(0.1,0.3,0.9) , design_formula = Y ~  G  +  Z , data = data , n2 = 200 )


result = twoPhaseOptimize(beta = beta[[1]], maf_G = c(0.1,0.2)[1], LD = c(0.1,0.3,0.9)[2] , design_formula = Y ~  G  +  Z , data = data , n2 = 200 )


result = result[ sapply(result,class) != "try-error" ]


v = sapply(result,function(x) { cat(x$R.opt.LM[1:40], "\n");  x$R.opt.LM  })
str(v)
image(v)


data_tmp  = data[1:2,]; data_tmp$G = 0.1; 
colnames(model.matrix(design_formula,data_tmp))


str(result)


nsample = 300


maf_G = 0.1
LD = 0.3

data = data.frame(  Y = rnorm(nsample),  Z = rbinom(nsample, 2, 0.2) , X = rnorm(nsample) ) 
beta = c( 1,1,1 )

n2 = 200
family = gaussian
design_formula =  Y ~  G  +  Z + X


#  result = twoPhase(beta = beta, maf_G = 0.1, LD = 0.3 , design_formula = Y ~  G  +  Z , data = data , n2 = 200 )


#beta = list( c(1,1,1), c(1,2,1), c(1,3,1) )

beta  = c(1,1,1)
result1 = twoPhaseDesign(beta = beta, maf_G = c(0.1,0.2), LD = c(0.1,0.3,0.9) , design_formula = design_formula , data = data , n2 = 200, overallMethod = "cumm" )

# beta = beta; maf_G = c(0.1); LD = c(0.1,0.3,0.9); design_formula = design_formula; data = data; n2 = 200; overallMethod = "cumm"; family = gaussian(); S = NA; perc_Y =  c(1/5,4/5); useGeneticAlgorithm = FALSE; optimCriterion = c("Par-spec","A-opt","D-opt")[1]
# optMethod = optimCriterion; 

str(result1)

sum(result1$overall_design$R.opt.LM)
table(result1$overall_design$Z,result1$overall_design$S,result1$overall_design$R.opt.LM)

colSums(result1$indiv_design)


result2 = twoPhaseDesign(beta = beta, maf_G = c(0.1), LD = c(0.1,0.3,0.9) , design_formula = design_formula , data = data , n2 = 200, design = "optGA" )
str(result2)
table(result2$overall_design$R.opt.GA)

table(result2$overall_design$Z,result2$overall_design$S,result2$overall_design$R.opt.GA)
colSums(result2$indiv_design)

result3 = twoPhaseDesign(beta = beta, maf_G = c(0.1), LD = c(0.1,0.3,0.9) , design_formula = design_formula , data = data , n2 = 200, design = "bal" )
str(result3)
table(result3$overall_design$Z,result3$overall_design$S,result3$overall_design$R.bal)
colSums(result3$indiv_design)
all.equal(result3$overall_design$R.bal,result3$indiv_design[,3])

result4 = twoPhaseDesign(beta = beta, maf_G = c(0.1), LD = c(0.1,0.3,0.9) , design_formula = design_formula , data = data , n2 = 200, design = "comb", ndraws = 5)
str(result4)
table(result4$overall_design$Z,result4$overall_design$S,result4$overall_design$R.comb)
table(result4$overall_design$Z,result4$overall_design$S,result4$indiv_design[,5])
all.equal(result4$overall_design$R.comb,result4$indiv_design[,5])
colSums(result4$indiv_design)

result4b = twoPhaseDesign(beta = beta, maf_G = c(0.1), LD = c(0.3) , design_formula = design_formula , data = data , n2 = 200, design = "comb", ndraws = 20)
str(result4b)
table(result4b$Z,result4b$S,result4b$R.comb)


resultHeur1 = twoPhaseHeuristic(design='comb', ndraws=10, data = data , n2 = 200)
colSums(resultHeur1)


nsample = 20000
data = data.frame(  Y = rnorm(nsample),  Z = rbinom(nsample, 2, 0.2) ) 

result = twoPhaseOptimalDesign(beta = c(-2,-3,1), maf_G = 0.24, LD = 0.8 , design_formula = Y ~  G  +  Z , data = data , n2 = 3000 )
result2 = twoPhaseOptimalDesign(beta = c(-2,-3,1), maf_G = 0.24, LD = 0.8 , design_formula = Y ~  G  +  Z , data = data , n2 = 3000, useGeneticAlgorithm = TRUE)
table(result$Z, result$S, result$R.opt.LM)
table(result$R.opt.LM)
table(result2$Z, result2$S, result2$R.opt.GA)
table(result2$R.opt.GA)





nsample = 10000
data = data.frame(  Y = rnorm(nsample),  Z = rbinom(nsample, 2, 0.2) ) 
result = twoPhaseOptimalDesign(beta = c(1,1), maf_G = 0.21, LD = 0.8 , design_formula = Y ~  G  , data = data , n2 = 100 )
result = twoPhaseOptimalDesign(beta = c(1,1), maf_G = 0.21, LD = 0.8 , design_formula = Y ~  G  , data = data , n2 = 1000 )
table(result$Z, result$S, result$R.opt.LM)
table(result$R.opt.LM)










nsample = 1000
data = data.frame(  Y = rnorm(nsample),  Z = rbinom(nsample, 2, 0.2) ) 

result = twoPhase(beta = c(1,1,1), maf_G = 0.21, LD = 0.8 , design_formula = Y ~  G + Z  , data = data , n2 = 100 )
result2 = twoPhase(beta = c(1,1,1), maf_G = 0.21, LD = 0.8 , design_formula = Y ~  G + Z  , data = data , n2 = 100 , useGeneticAlgorithm = TRUE)

result = twoPhase(beta = c(100,100), maf_G = 0.24, LD = 0.5 , design_formula = Y ~  G  , data = data , n2 = 200)

result = twoPhase(beta = c(1,5), maf_G = 0.24, LD = 0.5 , design_formula = Y ~  G  , data = data , n2 = 200)
result2 = twoPhase(beta = c(1,5), maf_G = 0.24, LD = 0.5 , design_formula = Y ~  G , data = data , n2 = 200 , useGeneticAlgorithm = TRUE)


table(result$Z, result$S, result$R.opt.LM)
table(result2$Z, result2$S, result2$R.opt.GA)

table(result$R.opt.LM , result2$R.opt.GA)
table(result2$R.opt.GA)






