library(MASS)
library(Matrix)
library(data.table)
library(dfoptim)
library(enrichwith)
library(nloptr)



source("package/R/DataGeneration.R")
source("package/R/kofnGA_mc.R")
source("package/R/optimJTC_v1.R")
source("package/R/SPML_glm_multipleG.R")


source("package/R/example1.R")
source("package/R/example2.R")
source("package/R/example3.R")

options(error = function() traceback(2))



runExample2(N = 1000, Beta0=2)

apo_datid
class.ind2.Mat(apo_datid)
as.matrix(  class.ind2.Mat(c(1,1,1,3,6,12)) )
class.ind2.Mat

cl = apo_datid
n <- length(cl)
cl <- as.factor(cl)
str(cl)
?unclass

x <- Matrix(0, n, length(levels(cl)))
x[(1L:n) + n * (unclass(cl) - 1L)] <- 1
dimnames(x) <- list(names(cl), levels(cl))
x