
### Packages ----
# required
require(Matrix)
require(data.table)
require(enrichwith)
require(nloptr)
require(dfoptim)
# optional (but recommended)
library(kofnGA)

### Source code ----
# required
source('SPML_glm_multipleG.R') ### This contains the functions for the semiparametric maximum likelihood estimation described in the paper
source("kofnGA_mc.R") ## This is my attempt of a multicored reimplementation of the main function in package kofnGA
source("optimJTC_v1.R") ### This contains the functions for optimal phase 2 sample selection described in the poster

# optional
source("DataGeneration_v2.R") ### This script contains a function that generates data given a few parameters

### Simulated data ----
## You could use this simulated dataset for ilustration, which I attached along the code
## Note that these data contain complete data (which has to be masked accordingly for analysis)
load("test_data.RData") ## loads dat_sim

## Alternatively, you could generate new datasets calling this function (in DataGeneration_v2.R). May be best to try with a smaller N to speed up the optimization under GA, for example.
if(0){
  N <- 5000
  Beta0 <- 2
  Beta1 <- 0.2
  LD.r <- 0.75
  P_g <- 0.2 
  P_z <- 0.3

  dat_sim <- DataGeneration_TPD(N = N, Beta0 = Beta0, Beta1=Beta1, Sigma2=1, LD.r=LD.r, P_g=P_g, P_z=P_z, tao = 2/5)
}
## Inputs above ##
# N: phase 1 sample size, i.e. GWAS data
# Beta0: intercept
# Beta1: genetic effect
# Sigma2: variance of the error term 
# LD.r: linkage disequilibrium (r) between G and Z
# P_g: minor allele frequency for G, the causal SNP
# P_z: minor allele frequency for Z, the GWAS SNP
# tao: quantile value to define the stratification for the quantitative trait

## The output of DataGeneration_TPD is a dataframe with complete data Y, G, Z, S, where G and Z come from the same haplotype determined by P_g, P_z and LD.r; Y is generated from Y = Beta0 + Beta1 x G, S is a 3 level variable determined by Y, Beta1, Sigma2 and tao. the function iterates across generated datasets until Z and Y are associated at a suggestive genome wide threshold of p<=1e-05.

### Optimal phase 2 sample selection ----
#** Data preparation ----
dat <- dat_sim[,c("Y","S","Z")] ## Keep only phase 1 data 

## determine "design" quantities to select the phase 2 data
beta0 <- c( 2, 0.1 ) ## intercept and genetic effects
p_Z <- data.frame(xtabs(~Z,dat)/nrow(dat))  ## calculates genotype distribution of Z from data
LD.r <- 0.75 ## specify LD between GWAS SNO, Z, and potentially "causal" locus
maf_G <- 0.2 ## specify MAF for potentially "causal" locus

### calculate p_gz, i.e. the joint distribution of G and Z using maf_G, LD.r and available data from Z using function p_gz_func() in optimJTC_v1.R. This procedure sometimes fails, if that's the case we may cheat a bit and use the complete data.
p_gz0 <- tryCatch(p_gz_func(p_Z, maf_G, LD.r, "G", "Z"), error=function(e){print(e); return(tryCatch(p_gz_func(0.3, maf_G, LD.r, "G", "Z"), error=function(e){NULL})) })
if( is.null(p_gz0) ){
  p_gz0 <- data.frame(xtabs(~G+Z,dat_sim))
  p_gz0$Freq <- p_gz0$Freq/sum(p_gz0$Freq)
  names(p_gz0) <- c("G","Z","q")
  p_gz0$G <- as.numeric(as.character(p_gz0$G))
  p_gz0$Z <- as.numeric(as.character(p_gz0$Z))
}

#** Phase 2 sample selection via 4 different methods ----
## This part selects phase 2 sample in four ways: 2 "intuitive" designs and 2 optimal designs. All these functions are located in optimJTC_v1.R.

## R1-R4 essentially contain a vector of size N with zeros (unselected) and ones (selected)

# These parameters are used in the functions
strataformula <- ~Z+S ## formula that determines the stratification factors, i.e. how the strata is defined (other formulas may be used, for example strataformula = ~S or strataformmula= ~Z). These must be discrete numeric variables in the phase 1 data
sel.prob.bal <- rep(1/9,9) ## selection probabilities for a balanced design
sel.prob.com <- c(1/6,1/6,1/6,0,0,0,1/6,1/6,1/6) ## selection probabilities for a combined design
N <- nrow(dat) ## phase 1 sample size
n2 <- round(N/2) ## phase 2 sample size, needs to be an integer less than N, in this case it is 50% of the phase 1 sample size
optMethod <- c("Par-spec","A-opt","D-opt")[1] ## optimality criterion (so far only these 3 implemented)
if( optMethod=="Par-spec" ){
  Kind <- 2
} else Kind <- NULL

# Basic stratified sampling for the "intuitive allocations"
R1 <- BSS(samp.fracs=sel.prob.bal,n2,dat,strataformula)$R ## indicators for balanced design
R2 <- BSS(samp.fracs=sel.prob.com,n2,dat,strataformula)$R ## indicators for combined design

## Lagrange multipliers (LM) approach
opt.prop <- optimJTC_FIM(formula=Y~G,miscov=~G,auxvar=~Z,strata=strataformula,family=gaussian,n=n2,data=dat,beta=beta0,p_gz=p_gz0,disp=NULL,optimMeasure=optMethod,K.idx=Kind,min.nk=NULL)
## Inputs above ##
# formula: regression formula, must contain at least the outcome Y from phase 1 data, it can additionally contain the phase 2 loci and other covariates from phase 1 
# miscov: right hand side formula with the missing-by-design covariate(s), i.e. the potential causal locus(loci) (not need to be a column in data)
# auxvar: right hand side formula with the auxiliary variable, i.e. the GWAS SNP from phase 1 (need to be a column in data)
# strata: right hand side formula with the stratification factors (they must be columns in data)
# family: member of the exponential family (see family, quasi models not available)
# n: phase 2 (fixed) sample size, must be an integer smaller than the number of rows in data
# data: dataframe containing the phase 1 data 
# beta: effects corresponding to the elements in the regression formula
# p_gz: dataframe with columns corresponding to ~ miscov + auxvar and their respective joint probability at each level
# disp: dispersion parameter, NULL by default (calculated from the data if this is the case). Takes 1 for binomial and poisson; a positive number for gaussian, Gamma and inverse.gaussian.
# optimMeasure: optimality criterion, one of "Par-spec", "A-opt" or "D-opt". "Par-spec" corresponds to a parameter specific criterion, "A-opt" to A-optimality and "D-opt" to D-optimality.
# K.idx: integer denoting the order of the parameter to study. Only relevant when optimMeasure is equal to "Par-spec".
# min.nk: optional parameter that determines the minimum number of subjects to select at each stratum

## Output of optimJTC_FIM() is a dataframe with columns defined by the strata formula, the number of elements from data and the optimal sampling fractions

# Perform basic stratified sampling on the optimal sampling probabilitites
R3 <- BSS.opt(samp.fracs=opt.prop$prR_cond_optim,dat,strata=strataformula) ## indicators for LM design


## For the genetic algorithm (GA), instead of providing a random initialization, I give an informed initialization based on combined, balanced and LM designs (a third each). 
pop1 <- sapply(1:20,function(x){
  sa <- which(BSS.opt(samp.fracs=opt.prop$prR_cond_optim,dat,strata=strataformula)==1)
  len <- length(sa)
  if( len==n2 ){ return(sa)
  }else if( len>n2 ){ return( sa[-sample(len, len-n2)] )
  }else return( c(sa,sample((1:N)[-sa],n2-len)) )
})
## combined
pop2 <- sapply(1:20,function(x){
  sa <- which(BSS(samp.fracs=sel.prob.com,n2,dat,strataformula)$R==1)
  len <- length(sa)
  if( len==n2 ){ return(sa)
  }else if( len>n2 ){ return( sa[-sample(len, len-n2)] )
  }else return( c(sa,sample((1:N)[-sa],n2-len)) )
})
## balanced
pop3 <- sapply(1:20,function(x){ 
  sa <- which(BSS(samp.fracs=sel.prob.bal,n2,dat,strataformula)$R==1)
  len <- length(sa)
  if( len==n2 ){ return(sa)
  }else if( len>n2 ){ return( sa[-sample(len, len-n2)] )
  }else return( c(sa,sample((1:N)[-sa],n2-len)) )
})

## Genetic Algorithm approach. This function may take a bit to run (in the order of a few minutes).
GA.sol <- optimJTC_GA(ncores=1,formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,n=n2,dat,beta=beta0,p_gz=p_gz0,disp=NULL,ga.popsize=60,ga.propelit=0.8,ga.proptourney=0.8,ga.ngen=300,ga.mutrate=0.001,ga.initpop=t(cbind(pop1,pop2,pop3)),optimMeasure=optMethod,K.idx=Kind,seed=1)

pop1a <- sapply(1:50,function(x){
  sa <- which(BSS.opt(samp.fracs=opt.prop$prR_cond_optim,dat,strata=strataformula)==1)
  len <- length(sa)
  if( len==n2 ){ return(sa)
  }else if( len>n2 ){ return( sa[-sample(len, len-n2)] )
  }else return( c(sa,sample((1:N)[-sa],n2-len)) )
})

GA.solA <- optimJTC_GA(ncores=1,formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,n=n2,dat,beta=beta0,p_gz=p_gz0,disp=NULL,ga.popsize=50,ga.propelit=0.05,ga.proptourney=0.1,ga.ngen=100,ga.mutrate=0.01,ga.initpop=t(cbind(pop1a)),optimMeasure=optMethod,K.idx=Kind,seed=1)

GA.solB <- optimJTC_GA(ncores=1,formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,n=n2,dat,beta=beta0,p_gz=p_gz0,disp=NULL,ga.popsize=50,ga.propelit=0.2,ga.proptourney=0.8,ga.ngen=300,ga.mutrate=0.001,ga.initpop=GA.solA$pop,optimMeasure=optMethod,K.idx=Kind,seed=1)

GA.solC <- optimJTC_GA(ncores=1,formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,n=n2,dat,beta=beta0,p_gz=p_gz0,disp=NULL,ga.popsize=50,ga.propelit=0.05,ga.proptourney=0.1,ga.ngen=100,ga.mutrate=0.01,ga.initpop=NULL,optimMeasure=optMethod,K.idx=Kind,seed=1)

GA.solD <- optimJTC_GA(ncores=1,formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,n=n2,dat,beta=beta0,p_gz=p_gz0,disp=NULL,ga.popsize=50,ga.propelit=0.2,ga.proptourney=0.8,ga.ngen=300,ga.mutrate=0.001,ga.initpop=GA.solC$pop,optimMeasure=optMethod,K.idx=Kind,seed=1)

## Inputs above ##
# ncores: number of cores for the multihreaded implementation
# formula: regression formula, must contain at least the outcome Y from phase 1 data, it can additionally contain the phase 2 loci and other covariates from phase 1 
# auxvar: right hand side formula with the missing-by-design covariate(s), i.e. the potential causal locus(loci) (not need to be a column in data)
# miscov: right hand side formula with the auxiliary variable, i.e. the GWAS SNP from phase 1 (need to be a column in data)
# strata: right hand side formula with the stratification factors (they must be columns in data)
# family: member of the exponential family (see family, quasi models not available)
# n: phase 2 (fixed) sample size, must be an integer smaller than the number of rows in data
# data: dataframe containing the phase 1 data 
# beta: effects corresponding to the elements in the regression formula
# p_gz: dataframe with columns corresponding to ~ miscov + auxvar and their respective joint probability at each level
# disp: dispersion parameter, NULL by default (calculated from the data if this is the case). Takes 1 for binomial and poisson; a positive number for gaussian, Gamma and inverse.gaussian.
# ga.popsize: population size for the genetic algorithm
# ga.propelit: elitism factor as a proportion of the population size, must be between 0 and 1 
# ga.proptourney: tournament size as a proportion of the population size, must be between 0 and 1 
# ga.ngen: number of generations of the genetic algorithm 
# ga.mutrate: mutation rate of the genetic algorithm, must be between 0 and 1, ideally small.
# ga.initpop: initial population, must be a matrix of size ga.popsize, n containing indices of the elements to be selected 
# optimMeasure: optimality criterion, one of "Par-spec", "A-opt" or "D-opt". "Par-spec" corresponds to a parameter specific criterion, "A-opt" to A-optimality and "D-opt" to D-optimality.
# K.idx: integer denoting the order of the parameter to study. Only relevant when optimMeasure is equal to "Par-spec".
# seed: for reproducibility, yet to be properly implemented

## Output of optimJTC_GA() is an object of class kofnGA with a few other elements for diagnostics.
plot(GA.solA)
plot(GA.solB)

R4 <- rep(0,nrow(dat)); R4[GA.solB$bestsol] <- 1  ## indicators for GA design


# Estimation via SPML ----
## The function SPML() takes the following inputs
# formula: regression formula, note that if it does not contain the missing-by-design variable, miscov, it will return results under the null hypothesis. Hypothesis testing corresponds to the score statistic. Otherwise, estimates and hypothesis testing ocurr under the alternative hypothesis leading to Wald statistics. All the elements in formula except miscov must be present in data0 and data1.
# miscov: right hand side formula with the missing-by-design covariate(s), i.e. the potential causal locus(loci). Must be present in data1 but absent in data0.
# auxvar: right hand side formula with the auxiliary variable, i.e. the GWAS SNP from phase 1. Must be present in data0 and data1
# family: member of the exponential family (see family, quasi models not available)
# data0: a dataframe with the complement of the phase 2 data 
# data1: a dataframe with the phase 2 data
# start.values: a named list with initial values for. Defaults to NULL
# verbose: verbose output? logical, defaults to FALSE.

### The output of SPML() is a list with the following elements:
## Under the null:
# theta: vector with the estimated parameters
# qGZ: dataframe with the estimated joint distribution between miscov and auxvar
# dispersion: dispersion parameter
# Sobs: score statistic based on the observed information matrix
# Sexp: score statistic based on the expected information matrix (probably needs to be removed) 
# df: degrees of freedom for the test
# qG: marginal distribution of miscov
# iter: number of iterations in the EM
# ll: log-likelihood

## Under the alternative:
# theta: vector with the estimated parameters
# qGZ: dataframe with the estimated joint distribution between miscov and auxvar
# dispersion: dispersion parameter
# var_theta: variance of theta
# Wobs: Wald statistic based on the observed information matrix
# Wexp: Wald statistic based on the expected information matrix (probably needs to be removed) 
# df: degrees of freedom for the test
# qG: marginal distribution of miscov
# iter: number of iterations in the EM
# ll: log-likelihood

### Given a set on indicators, we can define phase 2 and phase 2 complement data using the simulated complete data as follows:
## Analysis with the balanced design
data1a <- dat_sim[R1==1,c("Y","G","Z","S")] # phase 2 data
data0a <- dat_sim[R1==0,c("Y","Z","S")] # phase 2 data complement

resHo_a <- SPML(formula=Y~1,miscov=~G,auxvar=~Z,family=gaussian,data0a,data1a)
resHa_a <- SPML(formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,data0a,data1a)

## Analysis with the combined design
data1b <- dat_sim[R2==1,c("Y","G","Z","S")] # phase 2 data
data0b <- dat_sim[R2==0,c("Y","Z","S")] # phase 2 data complement

resHo_b <- SPML(formula=Y~1,miscov=~G,auxvar=~Z,family=gaussian,data0b,data1b)
resHa_b <- SPML(formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,data0b,data1b)

## Analysis with the optimal design via LM
data0c <- dat_sim[R3==0,c("Y","Z")]
data1c <- dat_sim[R3==1,c("Y","Z","G")]

resHo_c <- SPML(formula=Y~1,miscov=~G,auxvar=~Z,family=gaussian,data0c,data1c)
resHa_c <- SPML(formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,data0c,data1c)

## Analysis with the optimal design via GA
data0d <- dat_sim[R4==0,c("Y","Z")]
data1d <- dat_sim[R4==1,c("Y","Z","G")]

resHo_d <- SPML(formula=Y~1,miscov=~G,auxvar=~Z,family=gaussian,data0d,data1d)
resHa_d <- SPML(formula=Y~G,miscov=~G,auxvar=~Z,family=gaussian,data0d,data1d)



