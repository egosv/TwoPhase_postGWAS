
library(twoPhaseGAS)
runExample2(N=100, Beta0=1)
