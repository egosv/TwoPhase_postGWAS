


#' Run example test case 3 (SPML)
#'
#'
#' @param N sample size in phase 1 GWAS (integer)
#' @param Beta0 true value for the intercept (real) 
#' @param Beta1 true value for the genetic effect (real) 
#' @param n sample size for the phase 2 targeted sequencing (integer), defaults to round(N/2,0)
#' 
#' @return no return value
#' 
#' @examples
#'
#' print(1)
#'
#' @export
runExample3 = function(N = 1000, Beta0 = 1, Beta1 = 0.5, n = round(N/2)) {


# N = 1000
# Beta0 = 1
  
data1 = runExample1(
  N = N  , Beta0 = Beta0 , Beta1 = Beta1
  # ,Beta0 = 10
)


dat = data1$dat
opt.prop = data1$opt.prop
strataformula = data1$strataformula
beta0  = data1$beta0
p_gz0 = data1$p_gz0


#dat[1:5,]
#dim(dat)

# Perform basic stratified sampling on the optimal sampling probabilitites
R3 <- BSS.opt(samp.fracs=opt.prop$prR_cond_optim,dat,strata=strataformula) ## indicators for LM design

n2 <- round(N/2)

## For the genetic algorithm (GA), instead of providing a random initialization, I give an informed initialization based on combined, balanced and LM designs (a third each). 
pop1 <- sapply(1:20,function(x)  {
  
  sa <- which(BSS.opt(samp.fracs=opt.prop$prR_cond_optim,dat,strata=strataformula)==1)
  len <- length(sa)
  if( len==n2 ){ return(sa) } else if( len>n2 ){ return( sa[-sample(len, len-n2)] ) } else {
    return( c(sa,sample((1:N)[-sa],n2-len)) )
  }
  
  
})




## combined

sel.prob.com <- c(1/6,1/6,1/6,0,0,0,1/6,1/6,1/6) ## selection probabilities for a combined design

pop2 <- sapply(1:20,function(x)  {
  
  
  sa <- which(BSS(samp.fracs=sel.prob.com,n2,dat,strataformula)$R==1)
  len <- length(sa)
  if( len==n2 ){ return(sa)
  }else if( len>n2 ){ return( sa[-sample(len, len-n2)] )
  }else return( c(sa,sample((1:N)[-sa],n2-len)) )
  
  
})


## balanced

sel.prob.bal <- rep(1/9,9) ## selection probabilities for a balanced design

pop3 <- sapply(1:20,function(x)  { 
  
  
  sa <- which(BSS(samp.fracs=sel.prob.bal,n2,dat,strataformula)$R==1)
  len <- length(sa)
  if( len==n2 ){ return(sa)
  }else if( len>n2 ){ return( sa[-sample(len, len-n2)] )
  }else return( c(sa,sample((1:N)[-sa],n2-len)) )
  
  
})


optMethod <- c("Par-spec","A-opt","D-opt")[1] ## optimality criterion (so far only these 3 implemented)
if( optMethod=="Par-spec" ){
  Kind <- 2
} else Kind <- NULL




##  Assess_fitness1   is the fitness function on file optimJTC_v1.R
library(profvis)
# e1=new.env(); load("env1.rdata",env=e1)

#source("optimJTC_v1.R")
#source("v2/optimJTC_v2.R")


allFitness = c()

options(error = function() traceback(2))

time0 = proc.time()
## Genetic Algorithm approach. This function may take a bit to run (in the order of a few minutes).



#profvis({
GA.sol <- optimTP.GA(ncores=1,
                      formula = Y ~ G , 
                      miscov  = ~ G  ,
                      auxvar = ~ Z ,
                      family = gaussian ,
                      n = n2 ,
                      dat ,
                      
                      beta = beta0,
                      p_gz = p_gz0,
                      disp = NULL,
                      
                      ga.popsize = 60,
                      ga.propelit = 0.2,
                      ga.proptourney = 0.2,
                      
                      ga.ngen = nrep,
                      
                      
                      ga.mutrate = 0.001,
                      
                      ga.initpop = t( cbind( pop1, pop2, pop3 ) ),
                      
                      optimMeasure = optMethod,
                      K.idx = Kind,
                      seed = 1
)
#})


time1 = proc.time()


time1-time0

}
