

#' Run example test case 1 for the package
#'
#'
#' @param N sample size
#' @param nrep number of GA iterations
#' 
#' @examples
#'
#' print(1)
#'
#' @export
runExample1 = function(N , Beta0, Beta1) {
  # The rest of the default parameters for the function below are:
  # Sigma2 = 1, N = 5000, LD.r = 0.75, P_g = 0.2, P_z = 0.3, tao = 2/5
  dat_sim = DataGeneration_TPD(N=N, Beta0=Beta0, Beta1=Beta1)
  
  dat <- dat_sim[,c("Y","S","Z")] ## Keep only phase 1 data 
  
  ## determine "design" quantities to select the phase 2 data
  beta0 <- c(Beta0, Beta1) ## intercept and genetic effects
  p_Z <- data.frame(xtabs(~Z,dat)/nrow(dat))  ## calculates genotype distribution of Z from data
  LD.r <- 0.75 ## specify LD between GWAS SNO, Z, and potentially "causal" locus
  maf_G <- 0.2 ## specify MAF for potentially "causal" locus
  
  ### calculate p_gz, i.e. the joint distribution of G and Z using maf_G, LD.r and available data from Z using function p_gz_func() in optimJTC_v1.R. This procedure sometimes fails, if that's the case we may cheat a bit and use the complete data.
  p_gz0 <- tryCatch(
      p_gz_func(p_Z, maf_G, LD.r, "G", "Z"), 
      error = function(e)  {
          print(e); print(p_Z);
        return( tryCatch(p_gz_func(0.3, maf_G, LD.r, "G", "Z"), error = function(e) { NULL } ) )  
      }
      
      
      
    )
  
  
  if( is.null(p_gz0) )  {
    p_gz0 <- data.frame(xtabs(~G+Z,dat_sim))
    p_gz0$Freq <- p_gz0$Freq/sum(p_gz0$Freq)
    names(p_gz0) <- c("G","Z","q")
    p_gz0$G <- as.numeric(as.character(p_gz0$G))
    p_gz0$Z <- as.numeric(as.character(p_gz0$Z))
    
    
  }
  
  #** Phase 2 sample selection via 4 different methods ----
  ## This part selects phase 2 sample in four ways: 2 "intuitive" designs and 2 optimal designs. All these functions are located in optimJTC_v1.R.
  
  ## R1-R4 essentially contain a vector of size N with zeros (unselected) and ones (selected)
  
  # These parameters are used in the functions
  strataformula <- ~Z+S ## formula that determines the stratification factors, i.e. how the strata is defined (other formulas may be used, for example strataformula = ~S or strataformmula= ~Z). These must be discrete numeric variables in the phase 1 data
  sel.prob.bal <- rep(1/9,9) ## selection probabilities for a balanced design
  sel.prob.com <- c(1/6,1/6,1/6,0,0,0,1/6,1/6,1/6) ## selection probabilities for a combined design
  N <- nrow(dat) ## phase 1 sample size
  
  cat("N=",N,"\n")
  n2 <- round(N/2) ## phase 2 sample size, needs to be an integer less than N, in this case it is 50% of the phase 1 sample size
  optMethod <- c("Par-spec","A-opt","D-opt")[1] ## optimality criterion (so far only these 3 implemented)
  if( optMethod=="Par-spec" ){
    Kind <- 2
  } else Kind <- NULL
  
  # Basic stratified sampling for the "intuitive allocations"
  R1 <- BSS(samp.fracs=sel.prob.bal,n2,dat,strataformula)$R ## indicators for balanced design
  R2 <- BSS(samp.fracs=sel.prob.com,n2,dat,strataformula)$R ## indicators for combined design
  
  ## Lagrange multipliers (LM) approach
  
  if(1)
    
    opt.prop <- optimTP.LM(formula=Y~G,miscov=~G,auxvar=~Z,strata=strataformula,family=gaussian,n=n2,data=dat,beta=beta0,p_gz=p_gz0,disp=NULL,optimMeasure=optMethod,K.idx=Kind,min.nk=NULL)
  
  
   
    list(
      dat = dat,
      dat_comp = dat_sim,
      opt.prop = opt.prop,
      strataformula = strataformula,
      n2 = n2,
      beta0 = beta0, 
      p_gz0 = p_gz0 
      
      )
      
}
  